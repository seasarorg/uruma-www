package org.seasar.uruma.rcp.blank;

/**
 * Uruma アプリケーションのためのダミークラスです。<br />
 * Uruma アプリケーションでは最低一つの Java クラスがクラスパス内に存在する必要があります。<br />
 * 他のクラスを作成した場合、本クラスは削除して構いません。
 */
public class Dummy {

}
